library(testthat)
library(Workout03Binomial)

test_check("Workout03Binomial")
